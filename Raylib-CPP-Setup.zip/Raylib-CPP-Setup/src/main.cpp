#include <raylib.h>

int main(){
    InitWindow(800, 600, "My Project");
    SetTargetFPS(120);
        
    while (!WindowShouldClose()){
        BeginDrawing();
        ClearBackground(Color{ 255, 255, 255, 255 });

	
                
        EndDrawing();
    }

    CloseWindow();
}